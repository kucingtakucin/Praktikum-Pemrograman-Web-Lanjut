<?php

class Controller {

    public function view()
    {

    }

}